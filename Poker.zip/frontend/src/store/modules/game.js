import axios from 'axios';
import router from "../../router";

const state = {
    playerId: null,
    gameId: null,
    gameState: null,
    gameRooms: []
};

const getters = {
    getGameRoom: state => state.gameState,
    getGameRooms: state => state.rooms
};

const actions = {
    async createGame(_, startingBet) {
        await axios.get(`/create/${startingBet}`);
    },
    async viewRooms({ commit }) {
        const response = await axios.get(`/rooms`);
        commit("updateRooms", response.data)
    },
    async joinGame({ commit }, {
        gameId,
        identity
    }) {
        const response = await axios.post(`${gameId}/join`, identity);
        commit("updatePlayerId", response.data)
        commit("updateGameId", gameId)
    },
    async getState({ commit, state }) {
        const response = await axios.get(`${state.gameId}/${state.playerId}/state`);
        if (response.status === 404) {
            router.push('/');
            return;
        }
        commit("updateGameData", response.data);
    },
    async playerIsReady({ state }) {
        await axios.get(`${state.gameId}/${state.playerId}/ready`)
    },
    async commitAction({ state }, action) {
        await axios.post(`${state.gameId}/${state.playerId}/action`, action);
    }
};

const mutations = {
    updateGameData: (state, latest) => state.gameState = latest,
    updatePlayerId: (state, latest) => state.playerId = latest,
    updateGameId: (state, latest) => state.gameId = latest,
    updateRooms: (state, latest) => state.rooms = latest ?? [],
};

export default {
    state,
    getters,
    actions,
    mutations
};