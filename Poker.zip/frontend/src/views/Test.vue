<template>
	<div class="room" v-if="getGameRoom">
		<div class="table">
			<template v-if="getGameRoom.status === 'waiting'">
				<div class="column">
					<label>Rundi ska fillu, duke prit lojtart...</label>
					<button @click="playerIsReady" v-if="!getGameRoom?.player?.isReady">I'm ready</button>
				</div>
			</template>
			<template v-else>
				<div class="cards">
					<img v-for="card in getGameRoom.communityCards" :src="'/cards/' + card + '.svg'" />
				</div>
				<label class="cards" style="text-align: right">
					Pare ntavolin: {{getGameRoom.pot}}c<br />
					<template v-if="getGameRoom.currentBet">
						Basti i fundit: {{getGameRoom.currentBet}}c
					</template>
				</label>

				<div class="cards smaller">
					<img v-for="card in getGameRoom.player.hand" :src="'/cards/' + card + '.svg'" />
				</div>
				<div v-if="getGameRoom.currentTurn === getGameRoom.player.id">
					<div class="cards" v-if="raise.inited">
						<label>Amount</label>
						<input type="number" v-model="raise.amount" style="width: 3em">
						<button @click="commitRaise">Raise</button>
						<button @click="raise.inited = false">Cancel</button>
					</div>
					<div class="cards" v-else>
						<button @click="fold">Fold</button>
						<button @click="check" v-if="!getGameRoom?.currentBet">Check</button>
						<button @click="call" v-if="getGameRoom?.currentBet">Call</button>
						<button @click="raise.inited = true">Raise</button>
					</div>
				</div>
			</template>
		</div>


		<div class="users">
			<div class="user" :class="getGameRoom.currentTurn === player.id ? 'bold' : ''" v-for="player in [getGameRoom.player, ...getGameRoom.otherPlayers]">
				<label>Lojtari: {{player.name}}</label>
				<label>Balanci: {{player.balance}}c</label>
				<label v-if="player.isFolded">Statusi: dorzu</label>
				<label v-else-if="player.isAllIn">Statusi: all in</label>
				<label v-else-if="getGameRoom.status === 'waiting'">
					<template v-if="player.isReady">
						Statusi: gati
					</template>
					<template v-else>
						Statusi: npritje
					</template>
				</label>
				<label v-else-if="getGameRoom.currentTurn === player.id">Status: renin</label>
				<label v-else>Status: nloj</label>
			</div>
		</div>
	</div>
</template>

<style scoped>
	.room {
		display: flex;
	}

	.bold {
		font-weight: 900;
	}

	.table {
		background-color: darkgreen;
		width: 80%;
		height: 50vh;
		border-radius: 2em;
		border: 1em inset black;
		display: flex;
		flex-direction: column;
	}

	.cards {
		display: flex;
		gap: 1em;
		justify-content: center;
		align-items: center;
		height: 40%
	}

		.cards > img {
			height: 80%
		}

		.cards.smaller > img {
			height: 50%
		}

	button {
		background-color: #fff;
		border: none;
		padding: .4em .75em;
		border-radius: .4em;
		font-size: .8em;
		min-width: 80px;
		display: block;
	}

	input {
		background-color: #fff;
		border: none;
		padding: .4em .75em;
		border-radius: .4em;
		font-size: .8em;
		text-align: right;
	}

	label {
		color: #fff;
		display: block;
	}

	.users label {
		color: unset;
	}

	.column {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		height: 100%;
		gap: 2em;
	}
</style>

<style>
	* {
		font-family: "Lucida Console";
		user-select: none;
	}

	input::-webkit-outer-spin-button,
	input::-webkit-inner-spin-button {
		-webkit-appearance: none;
		margin: 0;
	}

	input[type=number] {
		-moz-appearance: textfield;
	}
</style>

<script>
	import { mapActions, mapGetters } from "vuex";
	export default {
		data() {
			return {
				raise: {
					inited: false,
					amount: 10
				}
			}
		},
		methods: {
			...mapActions(['getState', 'playerIsReady', 'commitAction']),

			async check() {
				await this.commitAction({
					type: "check"
				})
			},
			async call() {
				await this.commitAction({
					type: "call"
				})
			},
			async fold() {
				await this.commitAction({
					type: "fold"
				})
			},
			async commitRaise() {
				if (!this.raise.amount)
					return;
				this.raise.inited = false;
				await this.commitAction({
					type: "bet",
					amount: this.raise.amount
				});
				this.raise.amount = 0;
			},

		},
		async mounted() {
			setInterval(async () => await this.getState(), 1000);
		},
		computed: mapGetters(['getGameRoom'])
	}
</script>