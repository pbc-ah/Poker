namespace Backend.Models;

public class ActionRequest
{
    public string Type { get; set; }
    public int? Amount { get; set; }
}

