
namespace Backend;

public class GameService
{
    public IEnumerable<Game> GetRooms() => _games.Select(_ => _.Value);

    private readonly Dictionary<string, Game> _games = [];

    public string CreateGame(int ante)
    {
        Game game = new(ante);
        _games[game.Id] = game;
        return game.Id;
    }

    public bool JoinGame(string gameId, Player player)
    {
        if (!_games.TryGetValue(gameId, out var game) || !game.IsWaiting)
            return false;

        game.Players.Add(player);
        return true;
    }

    public bool StartGame(string gameId, string deckSeed)
    {
        if (!_games.TryGetValue(gameId, out var game) || !game.IsWaiting)
            return false;

        if (game.Players.Count < 2)
            return false;

        foreach (var player in game.Players)
        {
            if (player.Balance < game.AnteAmount)
                return false;

            player.Balance -= game.AnteAmount;
            game.Pot += game.AnteAmount;
            game.PlayerBets[player.Id] = 0;
        }

        game.Status = "started";
        game.DeckSeed = deckSeed;

        DealHands(game);

        game.CommunityCards.AddRange(DrawCards(game, 3));

        return true;
    }

    private void DealHands(Game game)
    {
        var deck = DeckHelper.CreateShuffledDeck(game.DeckSeed);

        foreach (var player in game.Players)
        {
            player.Hand.Clear();
            player.Hand.Add(deck.DrawCard());
            player.Hand.Add(deck.DrawCard());
        }
    }

    public Game GetGame(string gameId)
        => _games.TryGetValue(gameId, out var g) ? g : null;

    public Player GetPlayer(string gameId, string playerId)
        => GetGame(gameId)?.Players.FirstOrDefault(p => p.Id == playerId);

    public bool SubmitAction(string gameId, string playerId, string actionType, int? betAmount = null)
    {
        var game = GetGame(gameId);
        if (game?.Status != "started")
            return false;

        var player = game.Players.FirstOrDefault(p => p.Id == playerId);
        if (player == null || player.IsFolded || player.IsAllIn)
            return false;

        var currentPlayer = game.Players[game.CurrentTurn];
        if (currentPlayer.Id != playerId)
            return false;

        var currentPlayerBet = game.PlayerBets.GetValueOrDefault(playerId, 0);

        switch (actionType.ToLower())
        {
            case "fold":
                player.IsFolded = true;
                break;

            case "check":
                if (currentPlayerBet < game.CurrentBet)
                    return false;
                break;

            case "call":
                int callAmount = game.CurrentBet - currentPlayerBet;
                if (player.Balance <= callAmount)
                {
                    game.PlayerBets[player.Id] += player.Balance;
                    game.Pot += player.Balance;
                    player.Balance = 0;
                    player.IsAllIn = true;
                }
                else
                {
                    player.Balance -= callAmount;
                    game.PlayerBets[player.Id] = game.CurrentBet;
                    game.Pot += callAmount;
                }
                break;

            case "bet":
                if (!betAmount.HasValue || betAmount.Value < game.CurrentBet || betAmount.Value > player.Balance)
                    return false;

                game.CurrentBet = betAmount.Value;
                if (player.Balance <= betAmount.Value)
                {
                    game.PlayerBets[player.Id] += player.Balance;
                    game.Pot += player.Balance;
                    player.Balance = 0;
                    player.IsAllIn = true;
                }
                else
                {
                    player.Balance -= betAmount.Value;
                    game.PlayerBets[player.Id] = betAmount.Value;
                    game.Pot += betAmount.Value;
                }
                break;

            default:
                return false;
        }

        if (game.Players.Count(p => !p.IsFolded && !p.IsAllIn) <= 1)
        {
            ResolveWinner(game);
            return true;
        }

        AdvanceTurn(game);

        if (AllPlayersActed(game))
            AdvanceBettingRound(game);

        return true;
    }

    private void AdvanceTurn(Game game)
    {
        int start = game.CurrentTurn;
        do
        {
            game.CurrentTurn = (game.CurrentTurn + 1) % game.Players.Count;
        } while ((game.Players[game.CurrentTurn].IsFolded || game.Players[game.CurrentTurn].IsAllIn) && game.CurrentTurn != start);
    }

    private bool AllPlayersActed(Game game)
    {
        var active = game.Players.Where(p => !p.IsFolded && !p.IsAllIn).ToList();
        return active.All(p => game.PlayerBets.GetValueOrDefault(p.Id, 0) == game.CurrentBet);
    }

    private void AdvanceBettingRound(Game game)
    {
        game.PlayerBets.Clear();
        game.CurrentBet = 0;

        if (game.BettingRound == 0) { }
        else if (game.BettingRound < 3)
            game.CommunityCards.AddRange(DrawCards(game, 1));
        else
        {
            ResolveWinner(game);
            return;
        }

        game.BettingRound++;
    }

    private List<string> DrawCards(Game game, int count)
    {
        var deck = DeckHelper.CreateShuffledDeck(game.DeckSeed);
        deck.RemoveCards(game.CommunityCards);
        foreach (var p in game.Players)
            deck.RemoveCards(p.Hand);

        List<string> cards = [];

        for (int i = 0; i < count; i++)
            cards.Add(deck.DrawCard());

        return cards;
    }

    private void ResolveWinner(Game game)
    {
        try
        {
            game.Status = "finished";

            var eligiblePlayers = game.Players.Where(p => !p.IsFolded).ToList();
            var totalBets = game.PlayerBets.Values.Sum();

            // If no side pots needed, just award main pot
            if (game.SidePots.Count == 0 && eligiblePlayers.Count > 0)
            {
                var winners = eligiblePlayers
                    .OrderByDescending(p => PokerHandEvaluator.Evaluate([.. p.Hand, .. game.CommunityCards]))
                    .ToList();

                var bestScore = PokerHandEvaluator.Evaluate([.. winners.First().Hand, .. game.CommunityCards]);
                var finalWinners = winners
                    .Where(w => PokerHandEvaluator.Evaluate(w.Hand.Concat(game.CommunityCards).ToList()) == bestScore)
                    .ToList();

                int share = game.Pot / finalWinners.Count;
                foreach (var winner in finalWinners)
                    winner.Balance += share;

                return;
            }

            // Recalculate side pots if not already done
            var sidePots = game.SidePots.Count > 0 ? game.SidePots : CalculateSidePots(game);

            foreach (var pot in sidePots)
            {
                var contenders = pot.EligiblePlayers
                    .Where(p => !p.IsFolded)
                    .ToList();

                if (contenders.Count == 0)
                    continue;

                var sorted = contenders
                    .OrderByDescending(p => PokerHandEvaluator.Evaluate([.. p.Hand, .. game.CommunityCards]))
                    .ToList();

                var bestScore = PokerHandEvaluator.Evaluate([.. sorted.First().Hand, .. game.CommunityCards]);
                var finalWinners = sorted
                    .Where(w => PokerHandEvaluator.Evaluate([.. w.Hand, .. game.CommunityCards]) == bestScore)
                    .ToList();

                int share = pot.Amount / finalWinners.Count;
                foreach (var winner in finalWinners)
                    winner.Balance += share;
            }
        }
        finally
        {
            game.Pot = 0;
            game.Players.ForEach(player =>
            {
                player.IsReady = false;
                player.IsAllIn = false;
                player.IsFolded = false;
            });
            game.CurrentBet = 0;
            game.CurrentTurn = 0;
            game.BettingRound = 0;
            game.SidePots = [];
            game.PlayerBets = [];
            game.CommunityCards = [];
            game.Status = "waiting";
        }
    }


    private List<SidePot> CalculateSidePots(Game game)
    {
        List<SidePot> pots = [];

        var bets = game.Players.ToDictionary(p => p, p => game.PlayerBets.GetValueOrDefault(p.Id, 0));

        while (bets.Values.Any(b => b > 0))
        {
            var min = bets.Values.Where(b => b > 0).Min();
            var eligible = bets.Where(b => b.Value > 0).Select(b => b.Key).ToList();
            pots.Add(new()
            {
                Amount = min * eligible.Count,
                EligiblePlayers = eligible
            });
            foreach (var p in eligible)
                bets[p] -= min;
        }

        return pots;
    }

    public GameState GetPlayerView(string gameId, string playerId)
    {
        var game = GetGame(gameId);
        if (game == null)
            return null;

        var player = GetPlayer(gameId, playerId);
        if (player == null)
            return null;

        return new()
        {
            GameId = game.Id,
            Status = game.Status,
            CommunityCards = game.CommunityCards,
            Pot = game.Pot,
            CurrentBet = game.CurrentBet,
            CurrentTurn = game.Players[game.CurrentTurn].Id,
            Player = player,
            OtherPlayers = game.Players
                .Where(p => p.Id != player.Id)
                .Select(p => PublicPlayer.Create(p, game.Status))
        };
    }

    public bool ConfirmPlayerReady(string gameId, string playerId)
    {
        var game = _games[gameId];

        game.Players.Find(_ => _.Id == playerId).IsReady = true;

        return game.Players.All(_ => _.IsReady) && StartGame(gameId, gameId);
    }
}
